# SHIVAM PIXA Desktop Edition - uninstall helper
# Removes the Desktop + Start Menu shortcuts and the local app profile.

$appDir = Join-Path $env:LOCALAPPDATA 'SHIVAMPIXSA'
foreach ($base in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
  $p = Join-Path $base 'S H I V A M PIXA.lnk'
  if (Test-Path $p) { Remove-Item $p -Force }
}
if (Test-Path $appDir) {
  try {
    Remove-Item $appDir -Recurse -Force
  } catch {
    Write-Host 'Close the S H I V A M PIXA window first, then run Uninstall again.'
    exit 1
  }
}
Write-Host 'S H I V A M PIXA Desktop Edition removed.'
exit 0
