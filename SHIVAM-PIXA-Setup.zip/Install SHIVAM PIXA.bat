@echo off
title S H I V A M PIXA - Desktop Setup
echo.
echo   Installing S H I V A M PIXA (Desktop Edition)...
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-helper.ps1"
if errorlevel 1 (
  echo.
  echo   Setup could not finish. Windows 10/11 always includes Microsoft Edge -
  echo   please make sure it is not removed, then run this file again.
  echo.
  pause
  exit /b 1
)
echo.
echo   Done! Look for "S H I V A M PIXA" on your Desktop and in the Start Menu.
echo   The app window is opening now. It works offline from the second launch.
echo.
timeout /t 6 >nul
exit /b 0
