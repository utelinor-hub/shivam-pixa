@echo off
title S H I V A M PIXA - Uninstall
echo.
echo   Removing S H I V A M PIXA (Desktop Edition)...
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0uninstall-helper.ps1"
if errorlevel 1 (
  echo.
  pause
  exit /b 1
)
echo.
timeout /t 4 >nul
exit /b 0
