# SHIVAM PIXA Desktop Edition - installer helper
# Creates %LOCALAPPDATA%\SHIVAMPIXSA, Desktop + Start Menu shortcuts that open
# the app in its OWN Edge app window (no browser tab, no Chrome), isolated
# profile, custom icon - then launches the app once so it installs itself
# (service worker + offline cache) Android-style.

$ErrorActionPreference = 'Stop'
$appDir  = Join-Path $env:LOCALAPPDATA 'SHIVAMPIXSA'
$edgeProfile = Join-Path $appDir 'Profile'
$appUrl  = 'https://utelinor-hub.github.io/shivam-pixa/'

try {
  # 1. locate Microsoft Edge (bundled with Windows 10/11)
  $edge = $null
  try {
    $k = Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe' -ErrorAction SilentlyContinue
    if ($k -and $k.'(default)' -and (Test-Path $k.'(default)')) { $edge = $k.'(default)' }
  } catch {}
  if (-not $edge) {
    $cand = "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe"
    if (Test-Path $cand) { $edge = $cand }
  }
  if (-not $edge) {
    $cand = "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe"
    if (Test-Path $cand) { $edge = $cand }
  }
  if (-not $edge) { $edge = 'msedge' }  # App Paths lookup - works on stock Windows 11

  # 2. folders + icon
  New-Item -ItemType Directory -Force -Path $appDir | Out-Null
  New-Item -ItemType Directory -Force -Path $edgeProfile | Out-Null
  # v3.29.1: the icon now has a fully transparent background (no white box).
  # Delete the old one first so the new file gets a fresh timestamp, then ask
  # Windows to refresh its icon cache so the Desktop icon updates instantly.
  Remove-Item -Force (Join-Path $appDir 'pixa-icon.ico') -ErrorAction SilentlyContinue
  Copy-Item -Force (Join-Path $PSScriptRoot 'pixa-icon.ico') (Join-Path $appDir 'pixa-icon.ico')
  try { Start-Process -FilePath 'ie4uinit.exe' -ArgumentList '-show' -WindowStyle Hidden } catch { }

  # 3. shortcuts: Desktop + Start Menu ("S H I V A M PIXA")
  $w = New-Object -ComObject WScript.Shell
  $lnkArgs = "--app=$appUrl --user-data-dir=`"$edgeProfile`" --no-first-run"
  foreach ($base in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
    $lnk = $w.CreateShortcut((Join-Path $base 'S H I V A M PIXA.lnk'))
    $lnk.TargetPath = $edge
    $lnk.Arguments = $lnkArgs
    $lnk.IconLocation = (Join-Path $appDir 'pixa-icon.ico') + ',0'
    $lnk.WorkingDirectory = Split-Path $edge
    $lnk.Description = 'S H I V A M PIXA - offline photo editor + collage'
    $lnk.Save()
  }

  # 4. first launch - the app registers its service worker and caches itself
  Start-Process -FilePath $edge -ArgumentList "--app=$appUrl", "`"--user-data-dir=$edgeProfile`"", '--no-first-run'
  exit 0
} catch {
  Write-Host ("Setup error: " + $_.Exception.Message)
  exit 1
}
