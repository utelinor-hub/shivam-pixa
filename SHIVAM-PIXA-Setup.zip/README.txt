S H I V A M PIXA - Desktop Edition (Windows 10 / 11)
=====================================================

INSTALL (30 seconds)
  1. Right-click this ZIP  ->  "Extract All..."  ->  open the extracted folder.
  2. Double-click  "Install SHIVAM PIXA".
     (If Windows SmartScreen asks: click "More info" -> "Run anyway".)
  3. The app opens in its OWN window - like any normal Windows app.
     "S H I V A M PIXA" icons appear on the Desktop and in the Start Menu.

WHAT YOU GET
  - Its own app window - NOT a browser tab. No Chrome needed.
  - Works 100% offline - your photos never leave your PC.
  - Android-style updates: when a new version is ready, the app shows it
    under Help -> "Install Update" (red dot on Help). Click it once with
    internet on - the app downloads and updates itself, then restarts.
    You never download anything again.

NOTE
  - The first launch needs internet one time, so the app can install its
    offline engine. Every launch after that works fully offline.
  - v3.29.1: the Desktop / Start Menu icon now has a fully transparent
    background (no more white box). Already installed? Just run Install
    again - it safely refreshes the icons and reopens the app.

UNINSTALL
  - Close the app window, then double-click  "Uninstall SHIVAM PIXA".

This setup package: v3.29.1
The app itself always updates itself to the latest version automatically.
